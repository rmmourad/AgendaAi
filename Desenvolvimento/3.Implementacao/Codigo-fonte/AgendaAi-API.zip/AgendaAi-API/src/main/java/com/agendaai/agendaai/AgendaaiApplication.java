package com.agendaai.agendaai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaaiApplication.class, args);
	}

}
