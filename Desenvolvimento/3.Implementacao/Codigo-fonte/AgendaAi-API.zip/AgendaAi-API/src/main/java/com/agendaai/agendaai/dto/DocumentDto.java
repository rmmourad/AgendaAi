package com.agendaai.agendaai.dto;

public record DocumentDto(String cpf,
                          String cnpj) {
}
